package so5.exceptions;

public class ProbNoFreeCPUsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3789955425651610147L;

}
